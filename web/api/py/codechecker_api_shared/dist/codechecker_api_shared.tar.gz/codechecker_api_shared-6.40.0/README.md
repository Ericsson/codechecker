This package contains the generated API types shared between multiple  
[CodeChecker](https://github.com/Ericsson/codechecker) API endpoints.
